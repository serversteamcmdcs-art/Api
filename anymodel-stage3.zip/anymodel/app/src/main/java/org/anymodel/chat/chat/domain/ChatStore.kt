package org.anymodel.chat.chat.domain

import kotlinx.coroutines.flow.Flow

/** Локальная история чатов (Room). */
interface ChatStore {
    /** Пустой запрос — все чаты; иначе поиск по названию и тексту сообщений. */
    fun observeChats(query: String): Flow<List<Chat>>
    fun observeMessages(chatId: Long): Flow<List<ChatMessage>>

    suspend fun getChat(id: Long): Chat?
    suspend fun getMessages(chatId: Long): List<ChatMessage>

    suspend fun createChat(title: String, model: String?): Long
    suspend fun renameChat(id: Long, title: String)
    suspend fun setChatModel(id: Long, model: String?)
    suspend fun deleteChat(id: Long)

    suspend fun addMessage(
        chatId: Long,
        role: Role,
        content: String,
        attachments: List<Attachment> = emptyList()
    ): Long

    suspend fun updateMessageContent(id: Long, content: String)
    suspend fun deleteMessage(id: Long)

    /** Удаляет все сообщения чата после указанного (само сообщение остаётся). */
    suspend fun deleteMessagesAfter(chatId: Long, messageId: Long)
}
