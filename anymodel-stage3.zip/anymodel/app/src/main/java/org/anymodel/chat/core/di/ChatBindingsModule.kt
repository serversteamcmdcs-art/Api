package org.anymodel.chat.core.di

import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import org.anymodel.chat.chat.data.ApiChatRepository
import org.anymodel.chat.chat.data.FileAttachmentRepository
import org.anymodel.chat.chat.data.RoomChatStore
import org.anymodel.chat.chat.domain.AttachmentRepository
import org.anymodel.chat.chat.domain.ChatRepository
import org.anymodel.chat.chat.domain.ChatStore

@Module
@InstallIn(SingletonComponent::class)
abstract class ChatBindingsModule {

    @Binds
    @Singleton
    abstract fun bindChatRepository(impl: ApiChatRepository): ChatRepository

    @Binds
    @Singleton
    abstract fun bindChatStore(impl: RoomChatStore): ChatStore

    @Binds
    @Singleton
    abstract fun bindAttachmentRepository(impl: FileAttachmentRepository): AttachmentRepository
}
