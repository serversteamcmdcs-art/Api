package org.anymodel.chat.chat.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    // ---- чаты ----

    @Query("SELECT * FROM chats ORDER BY updatedAt DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    /** [query] должен быть уже приведён к нижнему регистру. */
    @Query(
        """
        SELECT * FROM chats
        WHERE instr(titleLower, :query) > 0
           OR EXISTS (
                SELECT 1 FROM messages m
                WHERE m.chatId = chats.id AND instr(m.contentLower, :query) > 0
           )
        ORDER BY updatedAt DESC
        """
    )
    fun searchChats(query: String): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE id = :id")
    suspend fun getChat(id: Long): ChatEntity?

    @Insert
    suspend fun insertChat(chat: ChatEntity): Long

    @Query("UPDATE chats SET title = :title, titleLower = :titleLower WHERE id = :id")
    suspend fun renameChat(id: Long, title: String, titleLower: String)

    @Query("UPDATE chats SET model = :model WHERE id = :id")
    suspend fun setChatModel(id: Long, model: String?)

    @Query("UPDATE chats SET updatedAt = :now WHERE id = :id")
    suspend fun touchChat(id: Long, now: Long)

    @Query("DELETE FROM chats WHERE id = :id")
    suspend fun deleteChat(id: Long)

    // ---- сообщения ----

    @Transaction
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY id")
    fun observeMessages(chatId: Long): Flow<List<MessageWithAttachments>>

    @Transaction
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY id")
    suspend fun getMessages(chatId: Long): List<MessageWithAttachments>

    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE messages SET content = :content, contentLower = :contentLower WHERE id = :id")
    suspend fun updateMessageContent(id: Long, content: String, contentLower: String)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: Long)

    @Query("DELETE FROM messages WHERE chatId = :chatId AND id > :messageId")
    suspend fun deleteMessagesAfter(chatId: Long, messageId: Long)

    // ---- вложения ----

    @Insert
    suspend fun insertAttachments(items: List<AttachmentEntity>)

    @Query("SELECT path FROM attachments WHERE messageId IN (SELECT id FROM messages WHERE chatId = :chatId)")
    suspend fun getAttachmentPathsForChat(chatId: Long): List<String>

    @Query("SELECT path FROM attachments WHERE messageId = :messageId")
    suspend fun getAttachmentPathsForMessage(messageId: Long): List<String>

    @Query(
        "SELECT path FROM attachments WHERE messageId IN " +
            "(SELECT id FROM messages WHERE chatId = :chatId AND id > :messageId)"
    )
    suspend fun getAttachmentPathsAfter(chatId: Long, messageId: Long): List<String>
}
