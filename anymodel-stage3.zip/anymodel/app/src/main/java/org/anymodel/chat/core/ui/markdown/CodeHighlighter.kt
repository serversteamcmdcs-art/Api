package org.anymodel.chat.core.ui.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

data class HighlightColors(
    val keyword: Color,
    val string: Color,
    val comment: Color,
    val number: Color
)

// Языки, в которых комментарий начинается с «#».
private val HASH_COMMENT_LANGS = setOf(
    "python", "py", "bash", "sh", "shell", "zsh", "yaml", "yml", "toml", "ruby", "rb",
    "dockerfile", "makefile", "r", "perl", "ini", "conf", "properties", "powershell", "ps1"
)

// Для этих «языков» подсветка не нужна.
private val PLAIN_LANGS = setOf("", "text", "txt", "plaintext", "plain", "markdown", "md", "log", "output", "console")

private val KEYWORDS = setOf(
    // общие
    "if", "else", "elif", "for", "while", "do", "switch", "case", "default", "break", "continue", "return",
    "try", "catch", "except", "finally", "throw", "throws", "raise", "new", "delete", "in", "is", "as", "not",
    "and", "or", "true", "false", "null", "none", "nil", "undefined", "this", "self", "super", "void",
    // объявления
    "class", "interface", "enum", "struct", "object", "trait", "impl", "type", "typealias", "namespace",
    "module", "package", "import", "from", "export", "using", "include", "extends", "implements",
    "fun", "func", "function", "def", "fn", "lambda", "val", "var", "let", "const", "static", "final",
    "abstract", "override", "open", "sealed", "data", "public", "private", "protected", "internal",
    "async", "await", "suspend", "yield", "with", "when", "match", "where", "pub", "mut", "ref", "go", "defer",
    // типы
    "int", "long", "short", "byte", "float", "double", "boolean", "bool", "char", "string", "str", "list", "dict",
    // sql
    "select", "insert", "update", "create", "table", "join", "left", "right", "inner", "outer", "on", "group",
    "by", "order", "having", "limit", "values", "set", "into", "distinct", "union", "alter", "drop", "index"
)

private const val STR_TRIPLE = "\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''"
private const val STR_DOUBLE = "\"(?:\\\\.|[^\"\\\\\\n])*\""
private const val STR_SINGLE = "'(?:\\\\.|[^'\\\\\\n])*'"
private const val STR_BACKTICK = "`[^`]*`"

private fun buildRegex(commentPattern: String) = Regex(
    "($commentPattern)" +
        "|($STR_TRIPLE|$STR_DOUBLE|$STR_SINGLE|$STR_BACKTICK)" +
        "|(\\b\\d+(?:\\.\\d+)?\\b)" +
        "|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)"
)

private val SLASH_REGEX = buildRegex("//[^\\n]*|/\\*[\\s\\S]*?\\*/")
private val HASH_REGEX = buildRegex("#[^\\n]*")

private const val MAX_HIGHLIGHT_CHARS = 20_000

/** Лёгкая подсветка без внешних библиотек: комментарии, строки, числа, ключевые слова. */
fun highlightCode(code: String, language: String, colors: HighlightColors): AnnotatedString {
    val lang = language.lowercase()
    if (lang in PLAIN_LANGS || code.length > MAX_HIGHLIGHT_CHARS) return AnnotatedString(code)

    val regex = if (lang in HASH_COMMENT_LANGS) HASH_REGEX else SLASH_REGEX
    return buildAnnotatedString {
        var last = 0
        for (match in regex.findAll(code)) {
            if (match.range.first > last) append(code.substring(last, match.range.first))
            val text = match.value
            when {
                match.groups[1] != null ->
                    withStyle(SpanStyle(color = colors.comment, fontStyle = FontStyle.Italic)) { append(text) }
                match.groups[2] != null ->
                    withStyle(SpanStyle(color = colors.string)) { append(text) }
                match.groups[3] != null ->
                    withStyle(SpanStyle(color = colors.number)) { append(text) }
                text.lowercase() in KEYWORDS ->
                    withStyle(SpanStyle(color = colors.keyword, fontWeight = FontWeight.SemiBold)) { append(text) }
                else -> append(text)
            }
            last = match.range.last + 1
        }
        if (last < code.length) append(code.substring(last))
    }
}
