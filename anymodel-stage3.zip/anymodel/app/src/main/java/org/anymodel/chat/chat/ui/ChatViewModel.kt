package org.anymodel.chat.chat.ui

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.anymodel.chat.R
import org.anymodel.chat.chat.domain.Attachment
import org.anymodel.chat.chat.domain.AttachmentException
import org.anymodel.chat.chat.domain.AttachmentRepository
import org.anymodel.chat.chat.domain.Chat
import org.anymodel.chat.chat.domain.ChatMessage
import org.anymodel.chat.chat.domain.ChatRepository
import org.anymodel.chat.chat.domain.ChatStore
import org.anymodel.chat.chat.domain.Role
import org.anymodel.chat.core.network.ApiErrors
import org.anymodel.chat.settings.domain.AiModel
import org.anymodel.chat.settings.domain.ApiKeyStore
import org.anymodel.chat.settings.domain.ModelsRepository
import org.anymodel.chat.settings.domain.SettingsRepository

/** Что делает кнопка «Повторить» в Snackbar для текущей ошибки. */
enum class ErrorAction { RETRY_GENERATION, RELOAD_MODELS, REFRESH, NONE }

data class ChatUiState(
    val chats: List<Chat> = emptyList(),
    val searchQuery: String = "",
    /** null — новый чат, который будет создан при первой отправке. */
    val currentChatId: Long? = null,
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val pending: List<Attachment> = emptyList(),
    val isGenerating: Boolean = false,
    val hasKey: Boolean = false,
    val models: List<AiModel> = emptyList(),
    val modelsLoading: Boolean = false,
    val defaultModel: String? = null,
    /** Модель, выбранная в этом чате; null — используется модель по умолчанию из настроек. */
    val modelOverride: String? = null,
    /** Текст ошибки для Snackbar; сбрасывается через [ChatViewModel.consumeError]. */
    val error: String? = null,
    val errorAction: ErrorAction = ErrorAction.REFRESH
) {
    val model: String? get() = modelOverride ?: defaultModel
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val chatRepository: ChatRepository,
    private val chatStore: ChatStore,
    private val attachments: AttachmentRepository,
    private val settingsRepository: SettingsRepository,
    private val apiKeyStore: ApiKeyStore,
    private val modelsRepository: ModelsRepository
) : ViewModel() {

    /** Локальное (не из БД) состояние экрана. */
    private val local = MutableStateFlow(ChatUiState(hasKey = apiKeyStore.hasKey()))

    /** Текст ответа, который «печатается» прямо сейчас: показываем его поверх сообщения из БД. */
    private data class StreamingOverlay(val messageId: Long, val content: String)

    private val streaming = MutableStateFlow<StreamingOverlay?>(null)

    private val chatsFlow = local
        .map { it.searchQuery }
        .distinctUntilChanged()
        .flatMapLatest { chatStore.observeChats(it) }

    private val messagesFlow = local
        .map { it.currentChatId }
        .distinctUntilChanged()
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList<ChatMessage>()) else chatStore.observeMessages(id)
        }

    val state: StateFlow<ChatUiState> = combine(local, chatsFlow, messagesFlow, streaming) { l, chats, msgs, overlay ->
        l.copy(chats = chats, messages = applyOverlay(msgs, overlay))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), local.value)

    private var generationJob: Job? = null
    private var modelsJob: Job? = null

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { s ->
                local.update { it.copy(defaultModel = s.defaultModel) }
            }
        }
        refresh()
    }

    private fun applyOverlay(messages: List<ChatMessage>, overlay: StreamingOverlay?): List<ChatMessage> =
        messages
            // Пустые ответы ассистента (оборванная генерация) не показываем.
            .filterNot { it.role == Role.ASSISTANT && it.content.isBlank() && it.id != overlay?.messageId }
            .map { if (it.id == overlay?.messageId) it.copy(content = overlay.content, isStreaming = true) else it }

    // ---------- ключ и модели ----------

    /** Вызывается при возврате на экран (например, из настроек): ключ и список моделей могли измениться. */
    fun refresh() {
        val hasKey = apiKeyStore.hasKey()
        local.update { it.copy(hasKey = hasKey) }
        if (hasKey && local.value.models.isEmpty()) loadModels()
    }

    private fun loadModels() {
        modelsJob?.cancel()
        modelsJob = viewModelScope.launch {
            local.update { it.copy(modelsLoading = true) }
            try {
                val models = modelsRepository.fetchModels()
                local.update { it.copy(models = models, modelsLoading = false) }
            } catch (t: Throwable) {
                ApiErrors.rethrowCancellation(t)
                local.update {
                    it.copy(
                        modelsLoading = false,
                        error = describe(t),
                        errorAction = ErrorAction.RELOAD_MODELS
                    )
                }
            }
        }
    }

    fun selectModel(id: String) {
        local.update { it.copy(modelOverride = id) }
        local.value.currentChatId?.let { chatId ->
            viewModelScope.launch { chatStore.setChatModel(chatId, id) }
        }
    }

    // ---------- ввод и вложения ----------

    fun onInputChange(value: String) = local.update { it.copy(input = value) }

    fun addAttachments(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            for (uri in uris) {
                if (local.value.pending.size >= MAX_PENDING) {
                    setError(context.getString(R.string.error_attachment_limit, MAX_PENDING), ErrorAction.NONE)
                    break
                }
                try {
                    val attachment = attachments.import(uri)
                    local.update { it.copy(pending = it.pending + attachment) }
                } catch (t: Throwable) {
                    ApiErrors.rethrowCancellation(t)
                    setError(describe(t), ErrorAction.NONE)
                }
            }
        }
    }

    fun removePending(attachment: Attachment) {
        attachments.discard(attachment)
        local.update { s -> s.copy(pending = s.pending.filterNot { it.path == attachment.path }) }
    }

    // ---------- чаты ----------

    fun newChat() {
        generationJob?.cancel()
        discardPending()
        local.update {
            it.copy(currentChatId = null, modelOverride = null, input = "", pending = emptyList(), error = null)
        }
    }

    fun openChat(id: Long) {
        if (id == local.value.currentChatId) return
        generationJob?.cancel()
        viewModelScope.launch {
            val chat = chatStore.getChat(id) ?: return@launch
            discardPending()
            local.update {
                it.copy(
                    currentChatId = id,
                    modelOverride = chat.model,
                    input = "",
                    pending = emptyList(),
                    error = null
                )
            }
        }
    }

    fun renameChat(id: Long, title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch { chatStore.renameChat(id, clean) }
    }

    fun deleteChat(id: Long) {
        val isCurrent = local.value.currentChatId == id
        if (isCurrent) generationJob?.cancel()
        viewModelScope.launch {
            chatStore.deleteChat(id)
            if (isCurrent) newChat()
        }
    }

    fun onSearchChange(query: String) = local.update { it.copy(searchQuery = query) }

    // ---------- отправка и генерация ----------

    fun send() {
        val s = local.value
        val text = s.input.trim()
        if ((text.isEmpty() && s.pending.isEmpty()) || s.isGenerating) return
        if (!apiKeyStore.hasKey()) {
            setError(context.getString(R.string.error_no_key), ErrorAction.REFRESH, hasKey = false)
            return
        }
        if (s.model == null) {
            setError(context.getString(R.string.error_no_model), ErrorAction.REFRESH)
            return
        }
        local.update { it.copy(isGenerating = true, input = "", pending = emptyList(), error = null) }
        viewModelScope.launch {
            val chatId = s.currentChatId
                ?: chatStore.createChat(makeTitle(text, s.pending), s.modelOverride).also { id ->
                    local.update { it.copy(currentChatId = id) }
                }
            chatStore.addMessage(chatId, Role.USER, text, s.pending)
            startGeneration(chatId)
        }
    }

    /** Остановить генерацию: уже полученный текст сохраняется в чате. */
    fun stop() {
        generationJob?.cancel()
    }

    /** Перегенерировать последний ответ (также используется кнопкой «Повторить» в Snackbar). */
    fun regenerate() {
        val chatId = local.value.currentChatId ?: return
        if (local.value.isGenerating) return
        local.update { it.copy(isGenerating = true, error = null) }
        viewModelScope.launch {
            val messages = chatStore.getMessages(chatId)
            val last = messages.lastOrNull()
            val lastUser = when {
                last == null -> null
                last.role == Role.ASSISTANT -> {
                    chatStore.deleteMessage(last.id)
                    messages.getOrNull(messages.lastIndex - 1)
                }
                else -> last
            }
            if (lastUser?.role == Role.USER) {
                startGeneration(chatId)
            } else {
                local.update { it.copy(isGenerating = false) }
            }
        }
    }

    /** Редактирование своего сообщения: ответы после него удаляются, ответ генерируется заново. */
    fun editMessage(messageId: Long, newText: String) {
        val chatId = local.value.currentChatId ?: return
        val text = newText.trim()
        if (text.isEmpty() || local.value.isGenerating) return
        local.update { it.copy(isGenerating = true, error = null) }
        viewModelScope.launch {
            chatStore.updateMessageContent(messageId, text)
            chatStore.deleteMessagesAfter(chatId, messageId)
            startGeneration(chatId)
        }
    }

    fun consumeError() = local.update { it.copy(error = null) }

    fun retry(action: ErrorAction) {
        when (action) {
            ErrorAction.RETRY_GENERATION -> regenerate()
            ErrorAction.RELOAD_MODELS -> loadModels()
            ErrorAction.REFRESH -> {
                local.update { it.copy(models = emptyList()) }
                refresh()
            }
            ErrorAction.NONE -> Unit
        }
    }

    private fun startGeneration(chatId: Long) {
        val model = local.value.model
        if (model == null) {
            local.update {
                it.copy(
                    isGenerating = false,
                    error = context.getString(R.string.error_no_model),
                    errorAction = ErrorAction.REFRESH
                )
            }
            return
        }

        generationJob = viewModelScope.launch {
            local.update { it.copy(isGenerating = true, error = null) }
            var assistantId = -1L
            val reply = StringBuilder()
            try {
                val history = chatStore.getMessages(chatId)
                assistantId = chatStore.addMessage(chatId, Role.ASSISTANT, "")
                streaming.value = StreamingOverlay(assistantId, "")

                val settings = settingsRepository.settings.first()
                var lastSave = SystemClock.elapsedRealtime()
                chatRepository.streamReply(
                    history = history,
                    model = model,
                    systemPrompt = settings.globalSystemPrompt,
                    temperature = settings.temperature,
                    maxTokens = settings.maxTokens
                ).collect { delta ->
                    reply.append(delta)
                    streaming.value = StreamingOverlay(assistantId, reply.toString())
                    // В БД пишем не чаще раза в ~0,8 с, чтобы переживать закрытие приложения без лишней нагрузки.
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSave > SAVE_INTERVAL_MS) {
                        chatStore.updateMessageContent(assistantId, reply.toString())
                        lastSave = now
                    }
                }
            } catch (t: Throwable) {
                ApiErrors.rethrowCancellation(t)
                setError(describe(t), ErrorAction.RETRY_GENERATION)
            } finally {
                // Отмена («Стоп») тоже приходит сюда: сохраняем то, что успели получить.
                withContext(NonCancellable) {
                    if (assistantId != -1L) {
                        if (reply.isBlank()) chatStore.deleteMessage(assistantId)
                        else chatStore.updateMessageContent(assistantId, reply.toString())
                    }
                    streaming.value = null
                    local.update { it.copy(isGenerating = false) }
                }
            }
        }
    }

    // ---------- вспомогательное ----------

    private fun setError(message: String, action: ErrorAction, hasKey: Boolean? = null) {
        local.update {
            it.copy(
                error = message,
                errorAction = action,
                hasKey = hasKey ?: it.hasKey
            )
        }
    }

    private fun describe(t: Throwable): String = when (t) {
        is AttachmentException -> context.getString(
            when (t.reason) {
                AttachmentException.Reason.UNSUPPORTED -> R.string.error_attachment_unsupported
                AttachmentException.Reason.TOO_LARGE -> R.string.error_attachment_too_large
                AttachmentException.Reason.READ_FAILED -> R.string.error_attachment_failed
            }
        )
        else -> ApiErrors.message(context, t)
    }

    private fun discardPending() {
        local.value.pending.forEach { attachments.discard(it) }
    }

    private fun makeTitle(text: String, pending: List<Attachment>): String {
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        val base = firstLine.ifEmpty { pending.firstOrNull()?.name.orEmpty() }
        return when {
            base.isEmpty() -> context.getString(R.string.default_chat_title)
            base.length > MAX_TITLE -> base.take(MAX_TITLE).trimEnd() + "…"
            else -> base
        }
    }

    private companion object {
        const val MAX_PENDING = 8
        const val MAX_TITLE = 40
        const val SAVE_INTERVAL_MS = 800L
    }
}
