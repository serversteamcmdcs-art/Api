package org.anymodel.chat.chat.data

import android.util.Base64
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.anymodel.chat.chat.domain.Attachment
import org.anymodel.chat.chat.domain.AttachmentKind
import org.anymodel.chat.chat.domain.ChatMessage
import org.anymodel.chat.chat.domain.ChatRepository
import org.anymodel.chat.core.network.ChatMessageDto
import org.anymodel.chat.core.network.ChatRequestDto
import org.anymodel.chat.core.network.ChatStreamer

@Singleton
class ApiChatRepository @Inject constructor(
    private val streamer: ChatStreamer
) : ChatRepository {

    override fun streamReply(
        history: List<ChatMessage>,
        model: String,
        systemPrompt: String,
        temperature: Float,
        maxTokens: Int?
    ): Flow<String> = flow {
        // Чтение вложений с диска и base64 — на IO, а не в главном потоке.
        val request = withContext(Dispatchers.IO) {
            val messages = buildList {
                if (systemPrompt.isNotBlank()) {
                    add(ChatMessageDto(role = "system", content = JsonPrimitive(systemPrompt.trim())))
                }
                history
                    .filter { it.content.isNotBlank() || it.attachments.isNotEmpty() }
                    .forEach { add(it.toDto()) }
            }
            ChatRequestDto(
                model = model,
                messages = messages,
                stream = true,
                temperature = temperature,
                maxTokens = maxTokens
            )
        }
        emitAll(streamer.stream(request))
    }

    private fun ChatMessage.toDto(): ChatMessageDto {
        val images = attachments.filter { it.kind == AttachmentKind.IMAGE }
        val files = attachments.filter { it.kind == AttachmentKind.TEXT }

        // Текстовые файлы встраиваются в текст сообщения (в историю чата при этом не попадают).
        val text = buildString {
            append(content)
            files.forEach { file ->
                val body = runCatching { File(file.path).readText() }.getOrDefault("")
                if (isNotEmpty()) append("\n\n")
                append("Файл «").append(file.name).append("»:\n```\n").append(body).append("\n```")
            }
        }

        if (images.isEmpty()) return ChatMessageDto(role = role.wire, content = JsonPrimitive(text))

        val parts: JsonElement = buildJsonArray {
            if (text.isNotBlank()) add(buildJsonObject { put("type", "text"); put("text", text) })
            images.forEach { add(imagePart(it)) }
        }
        return ChatMessageDto(role = role.wire, content = parts)
    }

    private fun imagePart(image: Attachment): JsonObject {
        val bytes = File(image.path).readBytes()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        return buildJsonObject {
            put("type", "image_url")
            put("image_url", buildJsonObject { put("url", "data:${image.mimeType};base64,$base64") })
        }
    }
}
