package org.anymodel.chat.core.ui.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle

/** Блочные элементы Markdown, которые умеет показывать приложение. */
sealed interface MdBlock {
    data class Paragraph(val text: String) : MdBlock
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Code(val language: String, val code: String) : MdBlock
    data class ListItem(val indent: Int, val marker: String, val text: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Table(val lines: List<String>) : MdBlock
    data object Rule : MdBlock
}

private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
private val LIST_ITEM = Regex("^(\\s*)([-*+]|\\d+[.)])\\s+(.*)$")
private val RULE = Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$")

/**
 * Разбирает Markdown на блоки. Устойчив к «недописанному» тексту из стриминга:
 * незакрытый блок кода считается кодом до конца текста.
 */
fun parseMarkdownBlocks(source: String): List<MdBlock> {
    val lines = source.replace("\r\n", "\n").split("\n")
    val blocks = mutableListOf<MdBlock>()
    val paragraph = StringBuilder()

    fun flushParagraph() {
        if (paragraph.isNotEmpty()) {
            blocks += MdBlock.Paragraph(paragraph.toString().trimEnd())
            paragraph.clear()
        }
    }

    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trimStart()

        when {
            trimmed.startsWith("```") -> {
                flushParagraph()
                val language = trimmed.removePrefix("```").trim().substringBefore(' ')
                val code = StringBuilder()
                i++
                var first = true
                while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                    if (!first) code.append('\n')
                    code.append(lines[i])
                    first = false
                    i++
                }
                blocks += MdBlock.Code(language, code.toString())
                // i указывает на закрывающую ограду (или за конец) — переход ниже пропустит её
            }

            line.isBlank() -> flushParagraph()

            HEADING.matches(line) -> {
                flushParagraph()
                val m = HEADING.find(line)!!
                blocks += MdBlock.Heading(m.groupValues[1].length, m.groupValues[2].trim())
            }

            RULE.matches(line) -> {
                flushParagraph()
                blocks += MdBlock.Rule
            }

            trimmed.startsWith(">") -> {
                flushParagraph()
                val quote = StringBuilder()
                while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                    if (quote.isNotEmpty()) quote.append('\n')
                    quote.append(lines[i].trimStart().removePrefix(">").removePrefix(" "))
                    i++
                }
                blocks += MdBlock.Quote(quote.toString())
                continue
            }

            trimmed.startsWith("|") -> {
                flushParagraph()
                val table = mutableListOf<String>()
                while (i < lines.size && lines[i].trimStart().startsWith("|")) {
                    table += lines[i].trim()
                    i++
                }
                blocks += MdBlock.Table(table)
                continue
            }

            LIST_ITEM.matches(line) -> {
                flushParagraph()
                val m = LIST_ITEM.find(line)!!
                blocks += MdBlock.ListItem(
                    indent = m.groupValues[1].length,
                    marker = m.groupValues[2],
                    text = m.groupValues[3]
                )
            }

            else -> {
                if (paragraph.isNotEmpty()) paragraph.append('\n')
                paragraph.append(line.trim())
            }
        }
        i++
    }
    flushParagraph()
    return blocks
}

/** Цвета для инлайн-разметки. */
data class InlineColors(val codeBackground: Color, val link: Color)

fun buildInline(text: String, colors: InlineColors): AnnotatedString =
    buildAnnotatedString { appendInline(text, colors) }

private const val ESCAPABLE = "\\`*_{}[]()#+-.!~|>"

private fun AnnotatedString.Builder.appendInline(text: String, colors: InlineColors) {
    val n = text.length
    var i = 0
    while (i < n) {
        val c = text[i]
        when {
            // экранирование: \* \_ \` ...
            c == '\\' && i + 1 < n && text[i + 1] in ESCAPABLE -> {
                append(text[i + 1])
                i += 2
            }

            // `код`
            c == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end > i) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = colors.codeBackground)) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(c)
                    i++
                }
            }

            // **жирный**
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        appendInline(text.substring(i + 2, end), colors)
                    }
                    i = end + 2
                } else {
                    append("**")
                    i += 2
                }
            }

            // ~~зачёркнутый~~
            text.startsWith("~~", i) -> {
                val end = text.indexOf("~~", i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                        appendInline(text.substring(i + 2, end), colors)
                    }
                    i = end + 2
                } else {
                    append("~~")
                    i += 2
                }
            }

            // *курсив*
            c == '*' && i + 1 < n && !text[i + 1].isWhitespace() -> {
                val end = findClosing(text, '*', i + 1, requireBoundary = false)
                if (end > 0) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        appendInline(text.substring(i + 1, end), colors)
                    }
                    i = end + 1
                } else {
                    append(c)
                    i++
                }
            }

            // _курсив_ (не трогаем snake_case)
            c == '_' && i + 1 < n && !text[i + 1].isWhitespace() &&
                (i == 0 || !text[i - 1].isLetterOrDigit()) -> {
                val end = findClosing(text, '_', i + 1, requireBoundary = true)
                if (end > 0) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        appendInline(text.substring(i + 1, end), colors)
                    }
                    i = end + 1
                } else {
                    append(c)
                    i++
                }
            }

            // [текст](https://ссылка)
            c == '[' -> {
                val closeBracket = text.indexOf(']', i + 1)
                val hasUrl = closeBracket > i && closeBracket + 1 < n && text[closeBracket + 1] == '('
                val closeParen = if (hasUrl) text.indexOf(')', closeBracket + 2) else -1
                if (hasUrl && closeParen > closeBracket) {
                    val label = text.substring(i + 1, closeBracket)
                    val url = text.substring(closeBracket + 2, closeParen).trim()
                    // Открываем только http(s): никаких intent:, file: и т.п.
                    if (url.startsWith("https://") || url.startsWith("http://")) {
                        val style = TextLinkStyles(
                            SpanStyle(color = colors.link, textDecoration = TextDecoration.Underline)
                        )
                        withLink(LinkAnnotation.Url(url, style)) { appendInline(label, colors) }
                    } else {
                        appendInline(label, colors)
                    }
                    i = closeParen + 1
                } else {
                    append(c)
                    i++
                }
            }

            else -> {
                append(c)
                i++
            }
        }
    }
}

private fun findClosing(text: String, marker: Char, from: Int, requireBoundary: Boolean): Int {
    var j = from
    while (j < text.length) {
        if (text[j] == marker && j > from && !text[j - 1].isWhitespace()) {
            val boundaryOk = !requireBoundary || j + 1 >= text.length || !text[j + 1].isLetterOrDigit()
            if (boundaryOk) return j
        }
        j++
    }
    return -1
}
