package org.anymodel.chat.core.ui.markdown

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.anymodel.chat.R

/** Показывает Markdown: заголовки, списки, цитаты, код с подсветкой и кнопкой «Копировать». */
@Composable
fun MarkdownText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = LocalContentColor.current
) {
    val blocks = remember(text) { parseMarkdownBlocks(text) }
    val inlineColors = InlineColors(
        codeBackground = color.copy(alpha = 0.12f),
        link = MaterialTheme.colorScheme.primary
    )

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Paragraph -> Text(
                    text = buildInline(block.text, inlineColors),
                    style = MaterialTheme.typography.bodyLarge,
                    color = color
                )

                is MdBlock.Heading -> Text(
                    text = buildInline(block.text, inlineColors),
                    style = when (block.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    },
                    fontWeight = FontWeight.Bold,
                    color = color
                )

                is MdBlock.ListItem -> Row(
                    modifier = Modifier.padding(start = (block.indent / 2 * 16).dp)
                ) {
                    val bullet = if (block.marker.first().isDigit()) block.marker else "•"
                    Text(
                        text = bullet,
                        style = MaterialTheme.typography.bodyLarge,
                        color = color,
                        modifier = Modifier.width(24.dp)
                    )
                    Text(
                        text = buildInline(block.text, inlineColors),
                        style = MaterialTheme.typography.bodyLarge,
                        color = color,
                        modifier = Modifier.weight(1f)
                    )
                }

                is MdBlock.Quote -> Row(modifier = Modifier.height(IntrinsicSize.Min)) {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(color.copy(alpha = 0.4f))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = buildInline(block.text, inlineColors),
                        style = MaterialTheme.typography.bodyLarge,
                        fontStyle = FontStyle.Italic,
                        color = color.copy(alpha = 0.85f)
                    )
                }

                is MdBlock.Code -> CodeBlock(language = block.language, code = block.code)

                is MdBlock.Table -> TableBlock(lines = block.lines, color = color)

                MdBlock.Rule -> HorizontalDivider(color = color.copy(alpha = 0.3f))
            }
        }
    }
}

@Composable
private fun TableBlock(lines: List<String>, color: Color) {
    // Таблицы показываем моноширинным текстом с горизонтальной прокруткой.
    Text(
        text = lines.joinToString("\n"),
        fontFamily = FontFamily.Monospace,
        style = MaterialTheme.typography.bodySmall,
        color = color,
        softWrap = false,
        modifier = Modifier.horizontalScroll(rememberScrollState())
    )
}

@Composable
private fun CodeBlock(language: String, code: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(2_000)
            copied = false
        }
    }

    val scheme = MaterialTheme.colorScheme
    val colors = HighlightColors(
        keyword = scheme.primary,
        string = scheme.tertiary,
        comment = scheme.onSurfaceVariant,
        number = scheme.secondary
    )
    val highlighted: AnnotatedString = remember(code, language, colors) {
        highlightCode(code, language, colors)
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = scheme.surfaceContainerHighest,
        contentColor = scheme.onSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "code" },
                    style = MaterialTheme.typography.labelMedium,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(code))
                        copied = true
                    }
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(if (copied) R.string.code_copied else R.string.code_copy),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            Text(
                text = highlighted,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                softWrap = false,
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
            )
        }
    }
}
