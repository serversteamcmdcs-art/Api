package org.anymodel.chat.core.db

import androidx.room.Database
import androidx.room.RoomDatabase
import org.anymodel.chat.chat.data.db.AttachmentEntity
import org.anymodel.chat.chat.data.db.ChatDao
import org.anymodel.chat.chat.data.db.ChatEntity
import org.anymodel.chat.chat.data.db.MessageEntity

@Database(
    entities = [ChatEntity::class, MessageEntity::class, AttachmentEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
}
