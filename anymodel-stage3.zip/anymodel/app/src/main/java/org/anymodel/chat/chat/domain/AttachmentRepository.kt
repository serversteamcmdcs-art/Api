package org.anymodel.chat.chat.domain

import android.net.Uri

interface AttachmentRepository {
    /**
     * Копирует выбранный файл в приватное хранилище приложения.
     * Картинки уменьшаются и сжимаются, текстовые файлы проверяются на размер.
     * Бросает [AttachmentException].
     */
    suspend fun import(uri: Uri): Attachment

    /** Удаляет копию файла (вложение убрали до отправки). */
    fun discard(attachment: Attachment)
}
