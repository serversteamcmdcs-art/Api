package org.anymodel.chat.chat.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import org.anymodel.chat.R
import org.anymodel.chat.chat.domain.ChatMessage
import org.anymodel.chat.chat.domain.Role

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onOpenSettings: () -> Unit,
    viewModel: ChatViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val retryLabel = stringResource(R.string.action_retry)
    var editing by remember { mutableStateOf<ChatMessage?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
    ) { uris -> viewModel.addAttachments(uris) }
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> viewModel.addAttachments(uris) }

    // Возврат из настроек: ключ и список моделей могли измениться.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refresh() }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    // Ошибки (401, 429, таймаут, нет сети, вложения): Snackbar, где нужно — с кнопкой «Повторить».
    LaunchedEffect(state.error) {
        val message = state.error ?: return@LaunchedEffect
        val action = state.errorAction
        val result = snackbarHostState.showSnackbar(
            message = message,
            actionLabel = if (action == ErrorAction.NONE) null else retryLabel,
            duration = SnackbarDuration.Long
        )
        viewModel.consumeError()
        if (result == SnackbarResult.ActionPerformed) viewModel.retry(action)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ChatDrawer(
                chats = state.chats,
                selectedId = state.currentChatId,
                query = state.searchQuery,
                onQueryChange = viewModel::onSearchChange,
                onNewChat = {
                    viewModel.newChat()
                    scope.launch { drawerState.close() }
                },
                onOpenChat = {
                    viewModel.openChat(it)
                    scope.launch { drawerState.close() }
                },
                onRenameChat = viewModel::renameChat,
                onDeleteChat = viewModel::deleteChat
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.drawer_open))
                        }
                    },
                    title = {
                        ModelPicker(
                            current = state.model,
                            models = state.models.map { it.id },
                            loading = state.modelsLoading,
                            onSelect = viewModel::selectModel
                        )
                    },
                    actions = {
                        IconButton(onClick = viewModel::newChat) {
                            Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.drawer_new_chat))
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.nav_settings))
                        }
                    }
                )
            },
            bottomBar = {
                MessageInput(
                    value = state.input,
                    pending = state.pending,
                    isGenerating = state.isGenerating,
                    enabled = state.hasKey,
                    onValueChange = viewModel::onInputChange,
                    onSend = viewModel::send,
                    onStop = viewModel::stop,
                    onPickPhoto = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickFile = { filePicker.launch(arrayOf("*/*")) },
                    onRemoveAttachment = viewModel::removePending
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when {
                    !state.hasKey -> EmptyState(
                        title = stringResource(R.string.chat_no_key_title),
                        body = stringResource(R.string.chat_no_key_body),
                        actionLabel = stringResource(R.string.chat_open_settings),
                        onAction = onOpenSettings
                    )
                    state.messages.isEmpty() -> EmptyState(
                        title = stringResource(R.string.chat_empty_title),
                        body = stringResource(R.string.chat_empty_body)
                    )
                    else -> MessageList(
                        messages = state.messages,
                        canModify = !state.isGenerating,
                        onRegenerate = viewModel::regenerate,
                        onEdit = { editing = it }
                    )
                }
            }
        }
    }

    editing?.let { message ->
        var text by remember(message.id) { mutableStateOf(message.content) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(stringResource(R.string.msg_edit_title)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 8
                )
            },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        viewModel.editMessage(message.id, text)
                        editing = null
                    }
                ) { Text(stringResource(R.string.chat_send)) }
            },
            dismissButton = {
                TextButton(onClick = { editing = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ModelPicker(
    current: String?,
    models: List<String>,
    loading: Boolean,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }, enabled = models.isNotEmpty() || current != null) {
            Text(
                text = current ?: stringResource(
                    if (loading) R.string.chat_models_loading else R.string.chat_model_none
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.widthIn(max = 180.dp)
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = stringResource(R.string.chat_select_model))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            models.forEach { id ->
                DropdownMenuItem(
                    text = { Text(id) },
                    onClick = {
                        onSelect(id)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun EmptyState(
    title: String,
    body: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (actionLabel != null && onAction != null) {
            Button(onClick = onAction, modifier = Modifier.padding(top = 16.dp)) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
private fun MessageList(
    messages: List<ChatMessage>,
    canModify: Boolean,
    onRegenerate: () -> Unit,
    onEdit: (ChatMessage) -> Unit
) {
    val lastId = messages.lastOrNull()?.id
    // reverseLayout: низ списка «приколот», поэтому растущий при стриминге ответ не уезжает вверх.
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        reverseLayout = true,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.Bottom)
    ) {
        items(messages.asReversed(), key = { it.id }) { message ->
            MessageItem(
                message = message,
                showRegenerate = canModify && message.id == lastId && message.role == Role.ASSISTANT,
                showEdit = canModify && message.role == Role.USER,
                onRegenerate = onRegenerate,
                onEdit = { onEdit(message) }
            )
        }
    }
}
