package org.anymodel.chat.chat.ui

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.anymodel.chat.R
import org.anymodel.chat.chat.domain.Attachment
import org.anymodel.chat.chat.domain.AttachmentKind
import org.anymodel.chat.chat.domain.ChatMessage
import org.anymodel.chat.chat.domain.Role
import org.anymodel.chat.core.ui.markdown.MarkdownText

@Composable
fun MessageItem(
    message: ChatMessage,
    showRegenerate: Boolean,
    showEdit: Boolean,
    onRegenerate: () -> Unit,
    onEdit: () -> Unit
) {
    val isUser = message.role == Role.USER
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val copiedToast = stringResource(R.string.msg_copied)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (message.attachments.isNotEmpty()) {
            AttachmentsRow(message.attachments)
        }

        if (isUser) {
            if (message.content.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.widthIn(max = 320.dp)
                ) {
                    SelectionContainer {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        } else if (message.content.isEmpty() && message.isStreaming) {
            CircularProgressIndicator(
                modifier = Modifier
                    .padding(start = 4.dp, top = 8.dp)
                    .size(20.dp),
                strokeWidth = 2.dp
            )
        } else {
            SelectionContainer {
                MarkdownText(
                    text = message.content,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp)
                )
            }
        }

        // Кнопки действий не показываем, пока ответ ещё печатается.
        if (!message.isStreaming && message.content.isNotBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                ActionIcon(
                    onClick = {
                        clipboard.setText(AnnotatedString(message.content))
                        Toast.makeText(context, copiedToast, Toast.LENGTH_SHORT).show()
                    }
                ) { Icon(Icons.Filled.ContentCopy, contentDescription = stringResource(R.string.msg_copy), modifier = Modifier.size(18.dp)) }

                if (showEdit) {
                    ActionIcon(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.msg_edit), modifier = Modifier.size(18.dp))
                    }
                }
                if (showRegenerate) {
                    ActionIcon(onClick = onRegenerate) {
                        Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.chat_regenerate), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(36.dp), content = content)
}

@Composable
private fun AttachmentsRow(attachments: List<Attachment>) {
    Row(
        modifier = Modifier
            .horizontalScroll(rememberScrollState())
            .padding(bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        attachments.forEach { AttachmentView(it) }
    }
}

@Composable
fun AttachmentView(attachment: Attachment) {
    if (attachment.kind == AttachmentKind.IMAGE) {
        AttachmentThumbnail(path = attachment.path, size = 96.dp)
    } else {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Filled.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(
                    text = attachment.name,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 160.dp)
                )
            }
        }
    }
}

/** Миниатюра картинки из приватной папки приложения (без сторонних библиотек загрузки). */
@Composable
fun AttachmentThumbnail(path: String, size: Dp, modifier: Modifier = Modifier) {
    val targetPx = with(LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<ImageBitmap?>(initialValue = null, path, targetPx) {
        value = withContext(Dispatchers.IO) { decodeThumbnail(path, targetPx) }
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        bitmap?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun decodeThumbnail(path: String, targetPx: Int): ImageBitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= targetPx && bounds.outHeight / (sample * 2) >= targetPx) sample *= 2
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
} catch (_: Exception) {
    null
}
