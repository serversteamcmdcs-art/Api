package org.anymodel.chat.chat.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.max
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.anymodel.chat.chat.domain.Attachment
import org.anymodel.chat.chat.domain.AttachmentException
import org.anymodel.chat.chat.domain.AttachmentException.Reason
import org.anymodel.chat.chat.domain.AttachmentKind
import org.anymodel.chat.chat.domain.AttachmentRepository

@Singleton
class FileAttachmentRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : AttachmentRepository {

    private val dir: File
        get() = File(context.filesDir, "attachments").also { it.mkdirs() }

    override suspend fun import(uri: Uri): Attachment = withContext(Dispatchers.IO) {
        val mime = context.contentResolver.getType(uri)
        val name = displayName(uri) ?: "file"
        try {
            if (mime != null && mime.startsWith("image/")) importImage(uri, name)
            else importText(uri, name, mime)
        } catch (e: AttachmentException) {
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw AttachmentException(Reason.READ_FAILED)
        }
    }

    override fun discard(attachment: Attachment) {
        runCatching { File(attachment.path).delete() }
    }

    // ---- текстовые файлы ----

    private fun importText(uri: Uri, name: String, mime: String?): Attachment {
        val bytes = context.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_TEXT_BYTES + 1) }
            ?: throw AttachmentException(Reason.READ_FAILED)
        if (bytes.size > MAX_TEXT_BYTES) throw AttachmentException(Reason.TOO_LARGE)
        // Нулевой байт — признак бинарного файла (PDF, архив, документ Office и т.п.).
        if (bytes.any { it == 0.toByte() }) throw AttachmentException(Reason.UNSUPPORTED)
        val file = newFile(name)
        file.writeBytes(bytes)
        return Attachment(
            name = name,
            mimeType = mime ?: "text/plain",
            kind = AttachmentKind.TEXT,
            path = file.absolutePath,
            sizeBytes = bytes.size.toLong()
        )
    }

    private fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        while (out.size() < limit) {
            val read = input.read(buffer, 0, minOf(buffer.size, limit - out.size()))
            if (read <= 0) break
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    // ---- картинки ----

    private fun importImage(uri: Uri, name: String): Attachment {
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw AttachmentException(Reason.READ_FAILED)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw AttachmentException(Reason.UNSUPPORTED)

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_IMAGE_SIDE) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw AttachmentException(Reason.READ_FAILED)

        val rotation = resolver.openInputStream(uri)?.use { readRotation(it) } ?: 0
        val longest = max(decoded.width, decoded.height)
        val matrix = Matrix().apply {
            if (longest > MAX_IMAGE_SIDE) {
                val scale = MAX_IMAGE_SIDE / longest.toFloat()
                postScale(scale, scale)
            }
            if (rotation != 0) postRotate(rotation.toFloat())
        }
        val oriented = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)

        // JPEG не поддерживает прозрачность — подкладываем белый фон.
        val flat = Bitmap.createBitmap(oriented.width, oriented.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply {
            drawColor(Color.WHITE)
            drawBitmap(oriented, 0f, 0f, null)
        }

        val jpgName = name.substringBeforeLast('.', name) + ".jpg"
        val file = newFile(jpgName)
        FileOutputStream(file).use { flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, it) }

        if (oriented !== decoded) decoded.recycle()
        oriented.recycle()
        flat.recycle()

        return Attachment(
            name = jpgName,
            mimeType = "image/jpeg",
            kind = AttachmentKind.IMAGE,
            path = file.absolutePath,
            sizeBytes = file.length()
        )
    }

    private fun readRotation(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (_: Exception) {
        0
    }

    // ---- общее ----

    private fun displayName(uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: uri.lastPathSegment
    } catch (_: Exception) {
        uri.lastPathSegment
    }

    private fun newFile(name: String): File {
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(80)
        return File(dir, "${UUID.randomUUID()}_$safe")
    }

    private companion object {
        const val MAX_TEXT_BYTES = 200 * 1024
        const val MAX_IMAGE_SIDE = 1536
        const val JPEG_QUALITY = 85
    }
}
