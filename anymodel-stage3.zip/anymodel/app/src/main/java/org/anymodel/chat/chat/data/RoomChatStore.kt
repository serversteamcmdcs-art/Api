package org.anymodel.chat.chat.data

import androidx.room.withTransaction
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.anymodel.chat.chat.data.db.AttachmentEntity
import org.anymodel.chat.chat.data.db.ChatDao
import org.anymodel.chat.chat.data.db.ChatEntity
import org.anymodel.chat.chat.data.db.MessageEntity
import org.anymodel.chat.chat.data.db.MessageWithAttachments
import org.anymodel.chat.chat.domain.Attachment
import org.anymodel.chat.chat.domain.AttachmentKind
import org.anymodel.chat.chat.domain.Chat
import org.anymodel.chat.chat.domain.ChatMessage
import org.anymodel.chat.chat.domain.ChatStore
import org.anymodel.chat.chat.domain.Role
import org.anymodel.chat.core.db.AppDatabase

@Singleton
class RoomChatStore @Inject constructor(
    private val db: AppDatabase,
    private val dao: ChatDao
) : ChatStore {

    override fun observeChats(query: String): Flow<List<Chat>> {
        val q = query.trim().lowercase()
        val source = if (q.isEmpty()) dao.observeChats() else dao.searchChats(q)
        return source.map { list -> list.map { it.toDomain() } }
    }

    override fun observeMessages(chatId: Long): Flow<List<ChatMessage>> =
        dao.observeMessages(chatId).map { list -> list.map { it.toDomain() } }

    override suspend fun getChat(id: Long): Chat? = dao.getChat(id)?.toDomain()

    override suspend fun getMessages(chatId: Long): List<ChatMessage> =
        dao.getMessages(chatId).map { it.toDomain() }

    override suspend fun createChat(title: String, model: String?): Long {
        val now = System.currentTimeMillis()
        return dao.insertChat(
            ChatEntity(
                title = title,
                titleLower = title.lowercase(),
                model = model,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    override suspend fun renameChat(id: Long, title: String) {
        dao.renameChat(id, title, title.lowercase())
    }

    override suspend fun setChatModel(id: Long, model: String?) {
        dao.setChatModel(id, model)
    }

    override suspend fun deleteChat(id: Long) {
        val paths = dao.getAttachmentPathsForChat(id)
        dao.deleteChat(id) // сообщения и вложения удаляются каскадом
        deleteFiles(paths)
    }

    override suspend fun addMessage(
        chatId: Long,
        role: Role,
        content: String,
        attachments: List<Attachment>
    ): Long = db.withTransaction {
        val now = System.currentTimeMillis()
        val messageId = dao.insertMessage(
            MessageEntity(
                chatId = chatId,
                role = role.wire,
                content = content,
                contentLower = content.lowercase(),
                createdAt = now
            )
        )
        if (attachments.isNotEmpty()) {
            dao.insertAttachments(
                attachments.map {
                    AttachmentEntity(
                        messageId = messageId,
                        name = it.name,
                        mimeType = it.mimeType,
                        kind = it.kind.name,
                        path = it.path,
                        sizeBytes = it.sizeBytes
                    )
                }
            )
        }
        dao.touchChat(chatId, now)
        messageId
    }

    override suspend fun updateMessageContent(id: Long, content: String) {
        dao.updateMessageContent(id, content, content.lowercase())
    }

    override suspend fun deleteMessage(id: Long) {
        val paths = dao.getAttachmentPathsForMessage(id)
        dao.deleteMessage(id)
        deleteFiles(paths)
    }

    override suspend fun deleteMessagesAfter(chatId: Long, messageId: Long) {
        val paths = dao.getAttachmentPathsAfter(chatId, messageId)
        dao.deleteMessagesAfter(chatId, messageId)
        deleteFiles(paths)
    }

    private suspend fun deleteFiles(paths: List<String>) {
        if (paths.isEmpty()) return
        withContext(Dispatchers.IO) { paths.forEach { runCatching { File(it).delete() } } }
    }

    private fun ChatEntity.toDomain() = Chat(id = id, title = title, model = model, updatedAt = updatedAt)

    private fun MessageWithAttachments.toDomain() = ChatMessage(
        id = message.id,
        role = Role.fromWire(message.role),
        content = message.content,
        attachments = attachments.map {
            Attachment(
                id = it.id,
                name = it.name,
                mimeType = it.mimeType,
                kind = runCatching { AttachmentKind.valueOf(it.kind) }.getOrDefault(AttachmentKind.TEXT),
                path = it.path,
                sizeBytes = it.sizeBytes
            )
        }
    )
}
