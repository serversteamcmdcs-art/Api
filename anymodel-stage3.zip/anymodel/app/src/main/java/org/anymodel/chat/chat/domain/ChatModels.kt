package org.anymodel.chat.chat.domain

enum class Role(val wire: String) {
    USER("user"),
    ASSISTANT("assistant");

    companion object {
        fun fromWire(value: String): Role = entries.firstOrNull { it.wire == value } ?: USER
    }
}

enum class AttachmentKind { IMAGE, TEXT }

data class Attachment(
    val id: Long = 0,
    val name: String,
    val mimeType: String,
    val kind: AttachmentKind,
    /** Абсолютный путь к копии файла в приватной папке приложения. */
    val path: String,
    val sizeBytes: Long
)

data class ChatMessage(
    val id: Long,
    val role: Role,
    val content: String,
    val isStreaming: Boolean = false,
    val attachments: List<Attachment> = emptyList()
)

data class Chat(
    val id: Long,
    val title: String,
    /** Модель, выбранная в этом чате; null — по умолчанию из настроек. */
    val model: String?,
    val updatedAt: Long
)

class AttachmentException(val reason: Reason) : Exception(reason.name) {
    enum class Reason { UNSUPPORTED, TOO_LARGE, READ_FAILED }
}
